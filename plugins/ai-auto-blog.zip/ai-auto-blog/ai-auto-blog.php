<?php
/**
 * Plugin Name: AI Auto Blog
 * Plugin URI: https://yourwebsite.com
 * Description: Automatically posts AI-generated blogs to a user’s WordPress site.
 * Version: 1.0
 * Author: Your Name
 * Author URI: https://yourwebsite.com
 * License: GPL2
 */

if (!defined('ABSPATH')) exit;

// Include necessary files
require_once plugin_dir_path(__FILE__) . 'includes/settings.php';
require_once plugin_dir_path(__FILE__) . 'includes/scheduler.php';
require_once plugin_dir_path(__FILE__) . 'includes/post-handler.php';
require_once plugin_dir_path(__FILE__) . 'includes/license.php';

// Activation Hook (sets up scheduled job)
function ai_auto_blog_activate() {
    if (!wp_next_scheduled('ai_auto_blog_daily_post')) {
        wp_schedule_event(time(), 'daily', 'ai_auto_blog_daily_post');
    }
}
register_activation_hook(__FILE__, 'ai_auto_blog_activate');

// Deactivation Hook (removes cron job)
function ai_auto_blog_deactivate() {
    wp_clear_scheduled_hook('ai_auto_blog_daily_post');
}
register_deactivation_hook(__FILE__, 'ai_auto_blog_deactivate');