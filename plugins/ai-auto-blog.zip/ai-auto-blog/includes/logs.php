<?php

if (!defined('ABSPATH')) exit; // Prevent direct access

/**
 * Logs messages to a file in the plugin directory.
 *
 * @param string $message The message to log.
 */
function ai_auto_blog_log($message) {
    // Path to the log file
    $log_file = plugin_dir_path(__FILE__) . '../logs.txt';

    // Create the log file if it doesn't exist
    if (!file_exists($log_file)) {
        file_put_contents($log_file, ""); // Create an empty file
    }

    // Add a timestamp to each log entry
    $timestamp = date("Y-m-d H:i:s");
    $log_message = "[{$timestamp}] {$message}" . PHP_EOL;

    // Write the message to the log file
    file_put_contents($log_file, $log_message, FILE_APPEND);
}