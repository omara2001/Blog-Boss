<?php

if (!defined('ABSPATH')) exit; // Prevent direct access

require_once plugin_dir_path(__FILE__) . 'logs.php'; // Include the logging utility

/**
 * Fetches AI-generated content and posts it to WordPress with the prompt.
 */
function ai_auto_blog_fetch_and_post() {
    // Get user settings
    $chatflow_id = get_option('ai_auto_blog_agent_url'); // AI Chatflow ID
    $site_url    = get_option('ai_auto_blog_site_url');   // WordPress Site URL
    $username    = get_option('ai_auto_blog_username');   // Admin Username
    $password    = get_option('ai_auto_blog_password');   // Admin Application Password
    $category    = get_option('ai_auto_blog_category');   // Post category ID
    $prompt      = get_option('ai_auto_blog_prompt');     // AI Prompt

    // Log the retrieved settings
    ai_auto_blog_log("INFO: Site URL: " . $site_url);
    ai_auto_blog_log("INFO: Username: " . $username);
    ai_auto_blog_log("INFO: Password: " . str_repeat('*', strlen($password))); // Masked password
    ai_auto_blog_log("INFO: Category ID: " . $category);
    ai_auto_blog_log("INFO: Agent URL: " . $chatflow_id);
    ai_auto_blog_log("INFO: Prompt: " . $prompt);

    // Validate required settings
    $missing_settings = [];
    if (empty($site_url)) $missing_settings[] = "WordPress Site URL";
    if (empty($username)) $missing_settings[] = "Admin Username";
    if (empty($password)) $missing_settings[] = "Admin Password";
    if (empty($category)) $missing_settings[] = "Post Category";
    if (empty($chatflow_id)) $missing_settings[] = "AI Agent URL";
    if (empty($prompt)) $missing_settings[] = "AI Prompt";

    if (!empty($missing_settings)) {
        ai_auto_blog_log("ERROR: Missing required settings - " . implode(", ", $missing_settings));
        return "ERROR: Missing required settings: " . implode(", ", $missing_settings);
    }

    // Construct the API URL using Chatflow ID
    $agent_url = "https://llminabox.criticalfutureglobal.com/api/v1/prediction/{$chatflow_id}";

    // Prepare the API request payload
    $payload = [
        "question" => $prompt // Prompt to send to the AI Agent
    ];

    ai_auto_blog_log("INFO: Sending prompt to AI Agent: {$prompt}");

    // Fetch AI-generated content (POST request)
    $response = wp_remote_post($agent_url, [
        'method'    => 'POST',
        'headers'   => [
            'Content-Type' => 'application/json',
        ],
        'body'      => json_encode($payload),
        'timeout'   => 60, // Increase timeout for slow responses
    ]);

    // Handle response errors
    if (is_wp_error($response)) {
        ai_auto_blog_log("ERROR: Failed to fetch AI-generated content.");
        return "ERROR: Failed to fetch AI-generated content.";
    }

    $response_body = wp_remote_retrieve_body($response);

    // Log the raw API response for debugging
    ai_auto_blog_log("INFO: Raw AI Response: " . print_r($response_body, true));

    // Decode JSON response
    $data = json_decode($response_body, true);

    if ($data === null || !isset($data['text'])) {
        ai_auto_blog_log("ERROR: Invalid AI response or missing 'text' field.");
        return "ERROR: Invalid AI response.";
    }

    // Use the AI-generated content
    $content = $data['text'];

    // Extract title from <h1> tag
    preg_match('/<h1>(.*?)<\/h1>/s', $content, $title_match);
    $title = isset($title_match[1]) ? sanitize_text_field($title_match[1]) : 'AI Generated Blog Post';

    ai_auto_blog_log("INFO: Extracted Title - " . $title);

    // Prepare the WordPress post data
    $post_data = [
        'title'       => $title,
        'content'     => $content, // Use the full HTML content
        'status'      => 'publish', // Change to 'draft' if manual review is required
        'categories'  => [$category],
    ];

    // Encode authentication for WordPress REST API
    $auth = base64_encode("{$username}:{$password}");

    // Send the post to the WordPress site
    $post_request = wp_remote_post("{$site_url}/wp-json/wp/v2/posts", [
        'headers' => [
            'Authorization' => "Basic {$auth}",
            'Content-Type'  => 'application/json',
        ],
        'body'    => json_encode($post_data),
        'method'  => 'POST',
    ]);

    // Handle post request response
    if (is_wp_error($post_request)) {
        ai_auto_blog_log("ERROR: Failed to publish post.");
        return "ERROR: Failed to publish post.";
    } else {
        ai_auto_blog_log("SUCCESS: Post published successfully.");
        return "SUCCESS: Post published successfully.";
    }
}
