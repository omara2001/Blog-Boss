<?php

if (!defined('ABSPATH')) exit; // Exit if accessed directly

// Schedule the Cron Job for Daily Blog Posting
function ai_auto_blog_schedule_cron() {
    if (!wp_next_scheduled('ai_auto_blog_daily_post')) {
        wp_schedule_event(time(), 'daily', 'ai_auto_blog_daily_post');
    }
}
register_activation_hook(__FILE__, 'ai_auto_blog_schedule_cron');

// Clear Scheduled Job on Plugin Deactivation
function ai_auto_blog_clear_cron() {
    wp_clear_scheduled_hook('ai_auto_blog_daily_post');
}
register_deactivation_hook(__FILE__, 'ai_auto_blog_clear_cron');

// Hook the Cron Event to the Posting Function
add_action('ai_auto_blog_daily_post', 'ai_auto_blog_generate_post');