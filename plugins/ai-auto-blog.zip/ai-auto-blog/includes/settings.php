<?php

if (!defined('ABSPATH')) exit; // Prevent direct access

/**
 * Adds the main menu for AI Auto Blog in WordPress Admin
 */
function ai_auto_blog_add_menu() {
    add_menu_page(
        'AI Auto Blog Settings',    // Page title
        'AI Auto Blog',             // Menu title
        'manage_options',           // Capability (Admin only)
        'ai-auto-blog',             // Menu slug
        'ai_auto_blog_settings_page', // Function to display content
        'dashicons-edit',           // Icon (changeable)
        25                          // Position in menu
    );
}
add_action('admin_menu', 'ai_auto_blog_add_menu');

/**
 * Function to display the settings page in the WordPress admin panel
 */
function ai_auto_blog_settings_page() {
    ?>
    <div class="wrap">
        <h1>AI Auto Blog Settings</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('ai_auto_blog_options'); // WordPress settings fields
            do_settings_sections('ai-auto-blog'); // Display settings sections
            submit_button(); // Save settings button
            ?>
        </form>
    </div>
    <?php
}

/**
 * Registers plugin settings fields in the WordPress database
 */
function ai_auto_blog_register_settings() {
    register_setting('ai_auto_blog_options', 'ai_auto_blog_site_url');   // WordPress Site URL
    register_setting('ai_auto_blog_options', 'ai_auto_blog_username');   // Admin Username
    register_setting('ai_auto_blog_options', 'ai_auto_blog_password');   // Admin Password
    register_setting('ai_auto_blog_options', 'ai_auto_blog_category');   // Post Category
    register_setting('ai_auto_blog_options', 'ai_auto_blog_agent_url');  // AI Agent URL
    register_setting('ai_auto_blog_options', 'ai_auto_blog_prompt');     // AI Prompt

    add_settings_section('ai_auto_blog_main', 'Main Settings', null, 'ai-auto-blog');

    add_settings_field('ai_auto_blog_site_url', 'WordPress Site URL', 'ai_auto_blog_site_url_callback', 'ai-auto-blog', 'ai_auto_blog_main');
    add_settings_field('ai_auto_blog_username', 'Admin Username', 'ai_auto_blog_username_callback', 'ai-auto-blog', 'ai_auto_blog_main');
    add_settings_field('ai_auto_blog_password', 'Application Password', 'ai_auto_blog_password_callback', 'ai-auto-blog', 'ai_auto_blog_main');
    add_settings_field('ai_auto_blog_category', 'Category ID', 'ai_auto_blog_category_callback', 'ai-auto-blog', 'ai_auto_blog_main');
    add_settings_field('ai_auto_blog_agent_url', 'AI Agent URL (Chatflow ID)', 'ai_auto_blog_agent_url_callback', 'ai-auto-blog', 'ai_auto_blog_main');
    add_settings_field('ai_auto_blog_prompt', 'AI Prompt', 'ai_auto_blog_prompt_callback', 'ai-auto-blog', 'ai_auto_blog_main');
}
add_action('admin_init', 'ai_auto_blog_register_settings');

// Callback functions for settings fields

function ai_auto_blog_site_url_callback() {
    $value = get_option('ai_auto_blog_site_url', '');
    echo '<input type="text" name="ai_auto_blog_site_url" value="' . esc_attr($value) . '" class="regular-text" placeholder="https://yourwebsite.com" />';
}

function ai_auto_blog_username_callback() {
    $value = get_option('ai_auto_blog_username', '');
    echo '<input type="text" name="ai_auto_blog_username" value="' . esc_attr($value) . '" class="regular-text" placeholder="admin" />';
}

function ai_auto_blog_password_callback() {
    $value = get_option('ai_auto_blog_password', '');
    echo '<input type="password" name="ai_auto_blog_password" value="' . esc_attr($value) . '" class="regular-text" placeholder="Application Password" />';
}

function ai_auto_blog_category_callback() {
    $value = get_option('ai_auto_blog_category', '');
    echo '<input type="number" name="ai_auto_blog_category" value="' . esc_attr($value) . '" class="small-text" placeholder="1" />';
}

function ai_auto_blog_agent_url_callback() {
    $value = get_option('ai_auto_blog_agent_url', '');
    echo '<input type="text" name="ai_auto_blog_agent_url" value="' . esc_attr($value) . '" class="regular-text" placeholder="Enter AI Agent Chatflow ID" />';
}

function ai_auto_blog_prompt_callback() {
    $value = get_option('ai_auto_blog_prompt', '');
    echo '<textarea name="ai_auto_blog_prompt" rows="5" class="large-text" placeholder="Enter your prompt here...">' . esc_textarea($value) . '</textarea>';
}

/**
 * Adds a submenu page to manually fetch & post AI-generated content
 */
function ai_auto_blog_fetch_and_post_button() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ai_auto_blog_fetch_post'])) {
        require_once plugin_dir_path(__FILE__) . 'post-handler.php';
        $response = ai_auto_blog_fetch_and_post();
        echo '<h3>Response:</h3>';
        echo '<pre>' . esc_html(print_r($response, true)) . '</pre>';
    }
    ?>
    <h2>Fetch & Post AI Blog</h2>
    <p>Click the button below to manually fetch an AI-generated article and publish it to your WordPress site.</p>
    <form method="post">
        <input type="hidden" name="ai_auto_blog_fetch_post" value="1">
        <button type="submit" class="button button-primary">Fetch & Post AI Blog</button>
    </form>
    <?php
}

// Add submenu under "AI Auto Blog"
add_action('admin_menu', function() {
    add_submenu_page(
        'ai-auto-blog',                // Parent menu slug
        'Fetch AI Blog',               // Page title
        'Fetch AI Blog',               // Menu title
        'manage_options',              // Capability
        'ai-auto-blog-fetch',          // Slug
        'ai_auto_blog_fetch_and_post_button' // Function to display test button
    );
});

/**
 * Adds a submenu page to view logs
 */
function ai_auto_blog_display_logs() {
    $log_file = plugin_dir_path(__FILE__) . '../logs.txt';

    echo '<h2>AI Auto Blog Logs</h2>';
    echo '<textarea rows="15" style="width:100%; font-family:monospace;" readonly>';

    if (file_exists($log_file)) {
        echo esc_textarea(file_get_contents($log_file));
    } else {
        echo "No logs found. Make sure logs.txt exists in the plugin directory.";
    }

    echo '</textarea>';
}

add_action('admin_menu', function() {
    add_submenu_page(
        'ai-auto-blog',          // Parent menu slug
        'Logs',                  // Page title
        'Logs',                  // Menu title
        'manage_options',        // Capability
        'ai-auto-blog-logs',     // Slug
        'ai_auto_blog_display_logs' // Function to display logs
    );
});
