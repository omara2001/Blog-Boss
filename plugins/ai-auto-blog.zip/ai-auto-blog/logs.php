<?php

if (!defined('ABSPATH')) exit; // Exit if accessed directly

function ai_auto_blog_log($message) {
    $log_file = plugin_dir_path(__FILE__) . '/logs.txt';
    $timestamp = date("Y-m-d H:i:s");
    $log_message = "[{$timestamp}] {$message}" . PHP_EOL;
    file_put_contents($log_file, $log_message, FILE_APPEND);
}
